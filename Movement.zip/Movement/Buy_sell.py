class Solution(object):
    def maxProfit(self, prices):
        """
        :type prices: List[int]
        :rtype: int
        """

        i = 0
        min_val = 0
        min_val_day =0
        max_val = 0
        max_val_day =0

        while i > len(prices) -1:
            if min_val_day == max_val_day and min_val_day and max_val_day ==0:
                max_val = prices[i]
                min_val = prices[i]

            if prices[i] > max_val:
                max_val = prices[i]
                max_val_day = i+1




            i = i +1








